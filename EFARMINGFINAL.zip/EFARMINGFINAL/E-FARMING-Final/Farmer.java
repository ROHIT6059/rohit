import java.util.*;
class Farmer 
{
   public String name;
   public int age;
   public long phoneNo;
   public int NoOfCrops;
  // public String[] crops = new String[NoOfCrops];
   Scanner scan = new Scanner(System.in);
   public Farmer()
   {
       
   }
   public Farmer(String name,int age,long phoneNo,int NoOfCrops)
   {
       this.name = name;
       this.age = age;
       this.phoneNo = phoneNo;
       this.NoOfCrops = NoOfCrops;
    
   }
   public void FarmerDetails()
   {
       System.out.println("Enter name:");
       name = scan.next();
       System.out.println("Enter age:");
       age = scan.nextInt();
       System.out.println("Enter phoneNo:");
       phoneNo = scan.nextLong();
       System.out.println("Enter No Of Crops of:"+name);
       NoOfCrops = scan.nextInt();
       
   }
 public void DisplayDetails()
{
 System.out.println("Name:"+name+"\t Age:"+age+"\t Phone no:"+phoneNo+ "\t No Of Crops:" +NoOfCrops );
  }

}



