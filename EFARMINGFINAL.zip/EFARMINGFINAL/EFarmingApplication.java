import java.util.Scanner;


class Operation
{
 public static void AdminOperation(Admin admin)
    {
    Scanner sc = new Scanner(System.in);
     boolean AdminLoggedIn = true;
 while (AdminLoggedIn) 
     {
	System.out.println("\n----ADMIN PAGE----");
              System.out.println("Enter choice");
              System.out.println("1) Add Crop Item.\n" + "2) Remove Crop Item \n" + "3) Update Crop Item \n"
					+ "4) Display Menu\n"  +"5) Farmers Details \n"  + "6) Exit");
              int choice = sc.nextInt();
              String Cropname = "";
               Double price= 0D;
               switch(choice)
	{ 
                   case 1: 
                          System.out.println("Enter the no of crops to add in menu");
                            int nofitems= sc.nextInt();
                          for(int i=0; i<nofitems; i++)
                          {
                            System.out.println("Enter crops: " + (i + 1));
                             Cropname =sc.next();
                             System.out.println("Enter it's price");
                              price =sc.nextDouble();
                             if(admin.Additem(Cropname,price))
                               System.out.println(Cropname + " added in menu.");
	             else
		System.out.println(Cropname  + " already in menu.");
		  admin.Additem(Cropname, price);
                        } break;
                  case 2:
                          System.out.println("Enter the Crop to remove from Menu:");
                           Cropname = sc.next();
                           if(admin.Deleteitem(Cropname))
                              System.out.println(Cropname+ "removed from Menu");
                           else
                              System.out.println(Cropname+ "does not exists in Menu");
                          break;
                 case 3:
                         System.out.println("Enter Cropname to update its price.");
	         Cropname= sc.next();
	         System.out.println("Enter its price.");
	           price = sc.nextDouble();
	            if (admin.Updateitem(Cropname, price))
		System.out.println("Menu updated.");
	            else
		System.out.println("Failed to update menu.");
	         break;
                case 4:
                          admin.DisplayMenu();
                          break;
               case 5:
                         System.out.println("** FARMERS DETAILS");
                         System.out.println("Enter no of farmers to be added");
                              int n = 2;
                                     Farmer[] f = new Farmer[n]; 
                              for(int i = 0 ; i < n; i++)
                                 {
                                     System.out.println((i+1));
                                      f[i] = new Farmer();
                                      f[i].FarmerDetails();   
                                 }
                               
                               System.out.println("Do you want to display farmers details.?(YES?NO)");
                                String displayfarmer = sc.next();
                               if(displayfarmer.equals("yes"))
                                    {
                                         System.out.println("***** Farmers Details *****");
                                             for(int i = 0 ; i < 2; i++)
                                               {
                                                   System.out.print((i+1)+ "\t");
                                                 f[i].DisplayDetails();   
                                             } 
                                    }
                              else
                                      return;

                       break;
             case 6:
                           return;
                 default:
                       System.out.println("Exiting from Admin Module.");
	       System.out.println("-------------------------------------");
	       AdminLoggedIn = false;
                }
               }
        sc.close();
    }

 public static void CustomerOperation(Customer customer)
  {
     Scanner sc =  new Scanner(System.in);
     boolean customerLoggedIn = true;
     while (customerLoggedIn) {
			System.out.println("----Please select your choice----");
			System.out.println("1) Display Menu \n" + "2) Order Product \n" + "3) Cancel Product \n"
					+ "4) Update Product Quantity \n" + "5) Display Order\n" + "6) Pay Bill  \n" +  "7) Exit\n");
			String Crop = " ";
			int quantity = 0;
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				System.out.println("----MENU----");
				customer.DisplayMenu();
				break;
			case 2:
				System.out.println("Enter product name to add.");
				Crop = sc.next();
				System.out.println("Enter " + Crop + "\'s quantity.");
				quantity = sc.nextInt();
				if (customer.Orderitem(Crop, quantity))
					System.out.println(quantity + " " + Crop + " added in order.");
				else
					System.out.println(Crop + " does not exist in menu.");
				break;
			case 3:
				System.out.println("Enter product to remove.");
				Crop  = sc.next();
				if (customer.Removeitem(Crop ))
					System.out.println(Crop  + " removed from order");
				else
					System.out.println("Failed to remove " + Crop );
				break;
			case 4:
				System.out.println("Enter product to update quantity.");
				Crop  = sc.next();
                                                                  System.out.println("Enternew quantity.");
				quantity  = sc.nextInt();
				if (customer.update(Crop, quantity))
					System.out.println(quantity + " " + Crop  + " added in order.");
				else
					System.out.println("Failed to update quantity for " + Crop);
				break;
			case 5:
				System.out.println("Your order is ");
				customer.DisplayOrder();
				break;
                                              case 6:
				System.out.println("Your total amount for following order ");
				System.out.println("-------------------------------------");
				System.out.println("PRODUCT \t QUANTITY");
				System.out.println("-------------------------------------");
				customer.DisplayOrder();
				System.out.println("Total Amount(including GST) = " + customer.totalBill());
				System.out.println("-------------------------------------\n");
				break;
			case 7:
				return;
				
			default:
				System.out.println("Exiting from Customer Module.");
				System.out.println("-------------------------------------");
				customerLoggedIn = false;
			}
		}
		sc.close();
	}
public static void FarmerOperation(Crops cropdetails)
    {
   Scanner sc =  new Scanner(System.in);
    System.out.println(" \n -----------------------------------------------\n \t\tWELCOME TO AGRI INFORMATION \n -----------------------------------------------");
  cropdetails.Additem();
    System.out.println("\nSelect the crops from below to show details:");
    cropdetails.Cropvalues();
       String crop = sc.next();
    cropdetails.DisplayCropDetails(crop);
   }
}
public class EFarmingApplication
{
   public static void main(String[] args)
    {
    EFarmingApplication efarm =new EFarmingApplication();
    Admin admin = new Admin();
   Customer customer = new Customer();
   Crops cropdetails = new Crops();
    Scanner sc = new Scanner(System.in);
    boolean wantToContinue = true;
     while (wantToContinue) 
    {
       System.out.println("\n------WELCOME TO E-FARMING -----\n");
       System.out.println("Login as:-    (Enter 1 for Admin & 2 for Farmer & 3 for Customer  ) ");
        System.out.println("1) Admin");
       System.out.println("2) Farmer");
        System.out.println("3) Customer");

        int loginAs = sc.nextInt();    
        switch (loginAs) {
	 case 1:
	     System.out.println("******ADMIN Credentials*****");
	      System.out.println("Enter username.");
	       String username = sc.next();
                       System.out.println("Enter password.");
	        String password = sc.next();
	        if ( admin.login(username, password))
                       {
                          Operation.AdminOperation(admin);
	         }
                          else  
                          {
		System.out.println("Invalid credentials.");
                              }
		break;
               case 2:
	Operation.FarmerOperation(cropdetails);
	   break;
	case 3:
	     Operation.CustomerOperation(customer);
	      break;
	default:
                          System.out.println("Invalid Choice!! " + "Terminating program.");
				wantToContinue = false;
			}

	}
		sc.close();
      }

}