import java.util.Scanner;
import java.util.HashMap; 
import java.util.HashSet;
import java.util.Set;
public class Admin {
    /* static HashMap to store all the crop and their respective price in menu. 
       Declared static so as to share same menu for all customers and Farmers.
	 */
    static HashMap<String,Double>Menu;
    
Admin(){
        Menu = new HashMap<String,Double>();}

    void DisplayMenu()
    {
        if(Menu.isEmpty())   
        {
        System.out.println("Menu is Empty");
        return ;
        }
       
   Set<String> Cropname = new HashSet<String>();
       Cropname = Menu.keySet();
              System.out.println("\t\t******* MENU ********" );
        System.out.println("\t--------------------------------" );
       System.out.println("\t \tCROPS \t PRICE " );
       System.out.println("\t----------------------------------" );
       for (String Crop : Cropname) {
			System.out.println("\t\t" +Crop + "\t" + Menu.get(Crop));
		}
      System.out.println("\t-----------------------------------" );
    } 
     boolean login(String username, String password)
     { 
           return username.equals("Admin") && password.equals("welcome123");
      }
     boolean Additem(String Crop,Double price)
     {     /* If menu already contains the crop don't add it in menu again and return false,
            Else add the crop in menu and return true.*/
        if(Menu.containsKey(Crop))
          return false;
        Menu.put(Crop, price);
          return true;
     }
     boolean Deleteitem(String Crop)
     {
         if(Menu.containsKey(Crop))
         {
             Menu.remove(Crop);
             return true;
         }else 
             return false;
     }
     
     boolean Updateitem(String Crop,Double price)
     { try{
         Deleteitem(Crop);
         Additem(Crop,price);}
     catch(Exception e){
     return false ;}   
     return true;
        
     }
    

    
}