import java.util.*;

public class Customer extends Admin  implements GST
{
   /*
	 * "order" HashMap to store the Crops and its quantity ordered by customer.
 */
  HashMap<String, Integer> Order;
	GST gst;

	Customer() {
		Order = new HashMap<String, Integer>();
		gst = null;
	}
    void DisplayMenu()
    {
         super.DisplayMenu();
    }
     boolean Orderitem(String Crop, int quantity)
     {
		/*
		 * Check if the menu contains the Cereal ordered by the customer. If it does
		 * not exist in menu return false, else add the cereal in customer's order.
		 */
		if (!super.Menu.containsKey(Crop))
			return false;
		Order.put(Crop, quantity);
		return true;

	}
     void DisplayOrder()
    {
       /* Check if the order HashMap is empty. If its empty then return, else display
      * all the food items and its quantity ordered by customer. */
        if(Order.isEmpty()){
            System.out.println("No items in order");
                 return;     
          }
          Set<String> Cropname = new HashSet<String>();
          Cropname = Order.keySet();
          System.out.println("-------------------------------------");
          System.out.println("CEREALS \t QUANTITY \t PRICE \t TOTAL");
          System.out.println("-------------------------------------");
           for (String Crop : Cropname)
          {
                System.out.println(Crop + "  \t " + Order.get(Crop) + "  \t " + Menu.get(Crop) + "   \t "+ Menu.get(Crop) * Order.get(Crop));
                 System.out.println();
          }
    System.out.println("-------------------------------------\n");
 }
boolean Removeitem(String Crop){
           /* * Check if the order contains the food item ordered by the customer. If it does
		 * not exist in order return false, else remove the food item from customer's
		 * order. */
      if(!Order.containsKey(Crop))
                 return false;
      else
            Order.remove(Crop);
       return true;
}
  boolean update(String Crop,int quantity) {
		/* * If the food item already exists in order, first remove the food item and then
		 * add the updated (food,quantity) in order. If food item does not exist in
		 * order it will just add it as a new entry. */
		try {
		     Order.remove(Crop);
			Order.put(Crop, quantity);
		} catch (Exception e) {
			return false;
		}
		return true;
	}
  double totalBill() {
		/*
		 * calculate the total amount for the products ordered including GST.
		 */
		double amount = 0;
		Set<String> Cropname = new HashSet<String>();
		Cropname= Order.keySet();
		for (String Crop : Cropname) {
			amount += (super.Menu.get(Crop) * Order.get(Crop));
		}
		double tax = gst.GSTTaxPercent * amount / 100;
		return amount + tax;
	}
}