import java.util.Scanner;
import java.util.HashMap; 
import java.util.HashSet;
import java.util.Set;
public class Crops {
    
    static HashMap<String,String>  CropsDetails;
    
Crops()
 {
        CropsDetails= new HashMap<String,String>();
}
    void DisplayCropDetails(String Crop)
    {
        if(!CropsDetails.containsKey(Crop) )
        {
        System.out.println("Invalid Data");
        return ;
        }
       else if(CropsDetails.isEmpty())   
        {
        System.out.println("Menu is Empty");
        return ;
        }
       
   Set<String> Cropname = new HashSet<String>();
 
       Cropname = CropsDetails.keySet();
              System.out.println("\t\t******* AGRI INFO ********" );
        System.out.println("\t--------------------------------" );
       System.out.println("\t \tCROPS \t INFORMATION " );
       System.out.println("\t----------------------------------" );
       System.out.println("\t\t" +Crop + "\t" + CropsDetails.get(Crop));
      System.out.println("\t-----------------------------------" );
    } 
  void Cropvalues()
  {
   Set<String> Cropname = new HashSet<String>();
    Cropname = CropsDetails.keySet();
        for (String Crop : Cropname) {
			System.out.println("\t\t" +Crop);
		}
     }
   
     void Additem()
     {     
       
        CropsDetails.put("Wheat","Temperature: Between 10-15°C (Sowing time) and 21-26°C (Ripening & Harvesting) with bright sunlight.\n\t\t\t Rainfall: Around 75-100 cm.\n\t\t\tSoil Type: Well-drained fertile loamy and clayey loamy.\n\t\t\tUse seed rate of 45 kg per acre \n\t\t\tFor seed treatment use fungicide as:- Raxil(2 gm),Thiram(2 gm) ");
        CropsDetails.put("Rice","Temperature: Between 22-32°C with high humidity.\n\t\t\tRainfall: Around 150-300 cm.\n\t\t\t Soil Type: Deep clayey and loamy soil.\n\t\t\t 8 kg seeds are sufficient for planting in one acre land.\n\t\t\tFungicides used to protect crop are: Trichoderma(5-10 gm),Chloropyriphos(5 ml)");
         CropsDetails.put("Jowar","Temperature: Between 27-32°C\n\t\t\tRainfall: Around 50-100 cm.\n\t\t\tSoil Type:  Rain-fed crop grown in the moist areas with less or no irrigation,because they are less sensitive to soil deficiencies\n\t\t\tSeed Rate:- under irrigated conditions-35 kg/acre & rainfed condition-45 kg/acre\n\t\t\t For seed treatment use Bavistin(2 gm/kg),Vitavax(2.5 gm/kg)");
           CropsDetails.put("Maize","Temperature: Between 21-27°C\n\t\t\tRainfall: High rainfall.\n\t\t\t Soil Type: Old alluvial soil.\n\t\t\t Seed- use 8-10 kg/acre.\n\t\t\t For treatment use: Imidalcloprid(5 ml),Captan(2.5 gm),Carbendazim(2 gm)");                         
          CropsDetails.put("Green Gram","(Moong)\n\t\t\t Temperature: Between 20-27°C\n\t\t\t Rainfall: Around 25-60 cm.\n\t\t\tSoil Type: Sandy-loamy soil.\n\t\t\tSeed rate:- for Kharif season= 8-9 kg/acre & summer season= 12-15 kg/acre \n\t\t\t Seed should be treated with Captan/Thiram @3 gm/kg of seed");
     }

    

    
}